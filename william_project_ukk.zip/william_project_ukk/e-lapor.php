<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="images/elapor-xicon.png">
    <title>E-LAPOR | DASHBOARD LAYANAN PELAPORAN MASYARAKAT</title>
</head>
<style>
    /* === E - LAPOR ROOT === */
    @import url('https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap');

    :root {
        --black: #34495E;
        --dark: #1D1A39;
        --purple-dark: #451952;
        --purple: #7324c7;
        --red-dark: #862549;
        --pink-lilac: #AE445A;
        --yellow: #F39F5A;
        --white-gray: #E8BCB9;
    }

    * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
        text-decoration: none;
        list-style: none;
        font-family: 'Nunito';
        color: var(--black);
    }

    html {
        scroll-behavior: smooth;
    }

    ::-webkit-scrollbar {
        width: 11px;
    }

    ::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }

    ::-webkit-scrollbar-thumb {
        background: var(--purple);
        border-radius: 10px;
        border: 2px solid #f1f1f1;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: var(--purple-dark);
    }

    /* = TITLE COLOR = */
    .title-to-combine {
        display: flex;
        gap: 6.5px;
    }
    .coloring-sub {
        color: var(--purple);
    }

    /* = NAVBAR = */
    nav .big-navbar {
        width: 100%;
        height: max-content;
        display: flex;
        justify-content: space-between;
        position: fixed;
        padding: 4vh 5vw;
        align-items: center;
        background-color: white;
    }

    .big-navbar {
        transition: all 0.3s ease-in-out;
    }

    .big-navbar.shrink {
        padding: 2vh 5vw;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .the-icon img {
        width: 150px;
        height: auto;
    }

    .navlist {
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .navlist ul {
        display: flex;
        align-items: center;
        gap: 15px;
    }

    .navlist ul li a {
        position: relative;
        overflow: hidden;
    }

    .navlist ul li a::after {
        content: "";
        position: absolute;
        bottom: 0;
        left: 0;
        width: 0%;
        height: 2px;
        background-color: var(--purple);
        transition: width 0.3s ease-in-out;
    }

    .navlist ul li a:hover::after {
        width: 100%;
    }

    .btn-design {
        background-color: var(--purple);
        color: white;
        padding: 7px 17px;
        border-radius: 5px;
        border: 2px solid var(--purple);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        transition: all .3s ease-in-out;
    }

    .btn-design:hover {
        background-color: white;
        color: var(--purple);
    }

    .navlist ul li a.active {
        color: var(--purple);
        font-weight: bold;
    }

    /* = HERO SECTION = */
    .big-hero-section {
        height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 4vw;
    }

    .hero1, .hero2 {
        width: 40%;
    }
    .hero1 h1 {
        font-size: 35px;
        margin-bottom: -3px;
    }
    .hero1 p {
        margin-top: 7px;
        margin-bottom: 20px;
    }

    .hero2 img {
        width: 90%;
        height: auto;
    }

    /* = SERVICES = */
    .big-services, .services-title {
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
        text-align: center;
    }

    .part-of-services {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 20px;
        margin-top: 40px;
        margin-bottom: 100px;
    }

    .part-of-services .services {
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: white;
        text-align: justify;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1), 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 7px;
        width: 27%;
    }
    .part-of-services .services h3 {
        color: black;
    }

    .img-ser {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .img-ser1, .img-ser2, .img-ser3 {
        background-color: whitesmoke;
        border-radius: 7px;
        padding: 13px;
        width: 130px;
        height: auto;
    }

    /* = HOW TO REPORT = */
    .big-report {
        height: 90vh;
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: whitesmoke;
    }

    .report-img {
        width: 35%;
    }

    .report-content {
        display: flex;
        gap: 30px;
        margin-top: 17px;
    }

    .step-font {
        display: flex;
        justify-content: center;
        align-items: center;
        text-align: center;
        width: 50px;
        height: 50px;
        color: white;
        border-radius: 50%;
        background-color: var(--purple);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1), 0 4px 8px rgba(0, 0, 0, 0.1);
    }
</style>
<body>
    <!-- NAVBAR -->
    <nav>
        <div class="big-navbar">
            <div class="the-icon">
                <a href="index.php"><img src="images/elapor-icon.png" alt="elapor-icon"></a>
            </div>
            <div class="navlist">
                <ul>
                    <li><a class="active" href="#home">Home</a></li>
                    <li><a href="#services">Services</a></li>
                    <li><a href="#footer">About</a></li>
                </ul>
            </div>
            <a class="btn-design" href="login.php">Sign Up</a>
        </div>
    </nav>
    <!-- HERO SECTION -->
    <div id="home" class="big-hero-section">
        <section class="hero1">
            <div class="title-to-combine">
                <h1>Platform</h1>
                <h1 class="coloring-sub">Pelaporan</h1>
            </div>
            <h1>Terpercaya untuk Masyarakat</h1>
            <p>E-Lapor memudahkan masyarakat untuk menyampaikan laporan, keluhan, atau masukan dengan cepat dan transparan, memastikan penanganan yang tepat oleh instansi terkait demi pelayanan publik yang lebih baik.</p>
            <a class="btn-design" href="login.php">Lapor Sekarang!</a>
        </section>
        <section class="hero2">
            <img src="images/on_LP1.png" alt="">
        </section>
    </div>
    <!-- SERVICES -->
    <div id="services" class="big-services">
        <div class="services-title">
            <section class="title-to-combine">
                <h1>We Provide The Best </h1>
                <h1 class="coloring-sub">Services</h1>
            </section>
            <p>Memberikan kemudahan bagi masyarakat untuk melaporkan masalah <br> dengan respon cepat.</p>
        </div>
        <div class="part-of-services" style="display: flex;">
            <div class="services">
                <section class="img-ser">
                    <img class="img-ser1" src="images/1-pelayanan.png" alt="">
                </section>
                <section style="padding: 20px;">
                    <h3>Pelayanan</h3>
                    <p>Laporan tentang layanan publik, seperti infrastruktur, pendidikan, atau kesehatan.</p>
                </section>
            </div>
            <div class="services">
                <section class="img-ser">
                    <img class="img-ser2" src="images/2-kebersihan.png" alt="">
                </section>
                <section style="padding: 20px;">
                    <h3>Kebersihan</h3>
                    <p>Laporan tentang sampah, saluran air tersumbat, atau masalah sanitasi.</p>
                </section>
            </div>
            <div class="services">
                <section class="img-ser">
                    <img class="img-ser3" src="images/3-keamanan.png" alt="">
                </section>
                <section style="padding: 20px;">
                    <h3>Keamanan</h3>
                    <p>Laporan tindakan kriminal atau gangguan ketertiban di lingkungan sekitar.</p>
                </section>
            </div>
        </div>
    </div>
    <!-- HOW TO REPORT -->
    <div id="report" class="big-report">
        <img src="images/on_LP2.png" alt="" class="report-img">
        <div class="report-title">
            <section class="title-to-combine">
                <h1>How to</h1>
                <h1 class="coloring-sub">Report?</h1>
            </section>
            <p style="margin-bottom: 40px;">Panduan Lengkap Langkah-Langkah Melaporkan di E-Lapor</p>
            <section class="report-content">
                <div class="step-font">
                    <h2 style="color: white;">1</h2>
                </div>
                <div class="step">
                    <h3 style="color: black;">Log In or Register</h3>
                    <p>Daftar atau masuk ke akun menggunakan data diri sesuai identitas kependudukan.</p>
                </div>
            </section>
            <section class="report-content">
                <div class="step-font">
                    <h2 style="color: white;">2</h2>
                </div>
                <div class="step">
                    <h3 style="color: black;">Fill Out the Report Form</h3>
                    <p>Pilih kategori, deskripsikan masalah, dan lampirkan bukti seperti foto atau dokumen.</p>
                </div>
            </section>
            <section class="report-content">
                <div class="step-font">
                    <h2 style="color: white;">3</h2>
                </div>
                <div class="step">
                    <h3 style="color: black;">Submit Your Report</h3>
                    <p>Pastikan semua data sudah benar, lalu kirim laporan Anda untuk diproses.</p>
                </div>
            </section>
            <section class="report-content">
                <div class="step-font">
                    <h2 style="color: white;">4</h2>
                </div>
                <div class="step">
                    <h3 style="color: black;">Track the Response</h3>
                    <p>Laporan akan ditindaklanjuti, dan tanggapan dari instansi terkait dapat dipantau.</p>
                </div>
            </section>
        </div>
    </div>
    <!-- FOOTER -->
    <footer id="footer" style="text-align: center; padding: 20px; background-color: var(--purple); font-size: 14px;">
        <p style="color: white;">&copy; 2024 I Putu William Vanther. All rights reserved.</p>
    </footer>
    <!-- SCRIPT -->
    <script>
        document.querySelectorAll('nav .navlist a').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });
        });

        const navbar = document.querySelector('.big-navbar');
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                navbar.classList.add('shrink');
            } else {
                navbar.classList.remove('shrink');
            }
        });

        const sections = document.querySelectorAll('section, div[id]');
        const navLinks = document.querySelectorAll('.navlist ul li a');
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.6
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const id = entry.target.getAttribute('id');
                    navLinks.forEach(link => {
                        link.classList.toggle('active', link.getAttribute('href') === `#${id}`);
                    });
                }
            });
        }, observerOptions);

        sections.forEach(section => observer.observe(section));
    </script>
    <!--  -->
</body>
</html>