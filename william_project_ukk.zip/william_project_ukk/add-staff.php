<?php
session_start();

if (!isset($_SESSION['level']) || !isset($_SESSION['nama_petugas'])) {
    header("Location: login.php");
    exit();
}

include_once 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_petugas = mysqli_real_escape_string($connection, $_POST['nama_petugas']);
    $username = mysqli_real_escape_string($connection, $_POST['username']);
    $password = mysqli_real_escape_string($connection, $_POST['password']);
    $telp = mysqli_real_escape_string($connection, $_POST['telp']);
    $level = mysqli_real_escape_string($connection, $_POST['level']);

    $hashed_password = md5($password);

    $check_sql = "SELECT * FROM petugas WHERE username = '$username'";
    $result = mysqli_query($connection, $check_sql);

    if (mysqli_num_rows($result) > 0) {
        header("Location: add-staff.php?status=duplicate");
        exit();
    } else {
        $sql = "INSERT INTO petugas (nama_petugas, username, password, telp, level) 
                VALUES ('$nama_petugas', '$username', '$hashed_password', '$telp', '$level')";

        if (mysqli_query($connection, $sql)) {
            header("Location: add-staff.php?status=success");
            exit();
        } else {
            header("Location: add-staff.php?status=error");
            exit();
        }
    }
}
mysqli_close($connection);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="images/elapor-xicon.png">
    <title>ADD STAFF E-LAPOR | DASHBOARD LAYANAN PELAPORAN MASYARAKAT</title>
</head>
<style>
    /* === E - LAPOR ROOT === */
    @import url('https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap');

    :root {
        --black: #34495E;
        --dark: #1D1A39;
        --purple-dark: #451952;
        --purple: #7324c7;
        --red-dark: #862549;
        --pink-lilac: #AE445A;
        --yellow: #F39F5A;
        --white-gray: #E8BCB9;
    }

    * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
        text-decoration: none;
        list-style: none;
        font-family: 'Nunito';
        color: var(--black);
    }

    body {
        background-color: #f1f2f7;
    }

    html {
        scroll-behavior: smooth;
    }

    ::-webkit-scrollbar {
        width: 12px;
    }

    ::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }

    ::-webkit-scrollbar-thumb {
        background: var(--purple);
        border-radius: 10px;
        border: 2px solid #f1f1f1;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: var(--purple-dark);
    }

    /* = NAVBAR = */
    nav {
        width: 18vw;
        height: 100vh;
        position: fixed;
        background-color: #f1f2f7;
        padding-bottom: 8vh;
    }

    .big-nav {
        border-right: 2px solid #d3d3d388;
        height: 100%;
    }

    .account {
        display: flex;
        align-items: center;
        flex-direction: column;
        justify-content: center;
        text-align: center;
        gap: 13px;
        margin: 4vh 0px 11vh 0px;
    }

    .bio-class:hover {
        text-decoration: underline;
    }

    .icon{
        width: 30%;
        margin-left: 2.5vw;
        padding-top: 1.7vh;
        color: var(--purple-dark);
        text-transform: uppercase;
    }
    .account img {
        width: 45%;
        border-radius: 50%;
        background-color: #C9B6F2;
        margin-top: 2vh;
    }
    .account section h1 {
        font-size: 20px;
        font-weight: bolder;
        margin: -1px 0;
    }
    .account section p {
        font-size: 11px;
        width: 220px;
        transition: all .3s ease-in-out;
    }
    .account section p:hover {
        color: #6c7b87;
    }

    .list-nav a {
        text-align: left;
        display: flex;
        align-items: center;
        gap: 20px;
        margin: 15px 0px;
    }

    .list-nav a i {
        background-color: white;
        color: gray;
        padding: 7px;
        border-radius: 12px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.01);
    }

    .list-nav a.active i {
        background-color: var(--purple);
        color: white;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .list-nav a.active h4, .list-nav a.active p {
        color: var(--purple);
    }

    .list-nav li {
        transform: scale(1);
        transition: all 0.3s ease-in-out;
    }
    .list-nav li:hover {
        transform: scale(1.01);
    }

    .button-logout {
        margin-top: 34.5vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .logout {
        display: flex;
        justify-content: center;
        align-items: center;
        font-weight: bold;
        background-color: var(--purple);
        color: white;
        font-size: 14px;
        padding: 10px 20px;
        width: 40%;
        max-width: 200px;
        border-radius: 7px;
        transition: all 0.3s ease-in-out;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        cursor: pointer;
    }

    .logout:hover {
        background-color: var(--yellow);
        color: var(--dark);
        box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
        transform: scale(1.05);
    }

    /* = CONTENT = */
    .big-content {
        margin: 4vh 0 4vh 20.5vw;
        width: 76.5vw;
        height: 92vh;
    }

    .form-pelaporan {
        height: 100%;
        background-color: #FFFFFF;
        padding: 7vh 7vw;
        border-radius: 12px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .form-pelaporan h2 {
        font-size: 20px;
        font-weight: bold;
        color: #333;
        margin-bottom: 5px;
        text-align: center;
    }
    .form-group, .form-pelaporan p {
        margin-bottom: 20px;
    }

    .form-group label {
        font-size: 14px;
        color: #555;
        margin-bottom: 8px;
        display: block;
        font-weight: 500;
    }

    .form-group input,
    .form-group textarea {
        width: 100%;
        padding: 10px 15px;
        border: 1px solid #E5E8EF;
        border-radius: 8px;
        font-size: 14px;
        color: #333;
        outline: none;
        transition: all 0.3s ease;
        background-color: #F9FAFB;
    }

    .form-group input:focus,
    .form-group textarea:focus {
        border-color: #6E6DFF;
        background-color: #FFF;
        box-shadow: 0 0 4px rgba(110, 109, 255, 0.5);
    }

    .form-group textarea {
        resize: none;
        height: 43vh;
    }

    .form-actions {
        text-align: center;
    }

    .form-actions button {
        background-color: #6E6DFF;
        color: #FFFFFF;
        border: none;
        padding: 10px 20px;
        border-radius: 8px;
        font-size: 14px;
        cursor: pointer;
        transition: all 0.3s ease;
    }

    .form-actions button:hover {
        background-color: #5554D4;
    }

    /* === PASSWORD INPUT === */
    .password-wrapper {
        position: relative;
        width: 100%;
    }

    .password-wrapper input {
        width: 100%;
        padding: 10px 15px;
        padding: 0.75rem;
        border: 1px solid #ccc;
        border-radius: 0.5rem;
        background-color: #f9f9f9;
    }

    .toggle-password {
        position: absolute;
        right: 1rem;
        top: 50%;
        transform: translateY(-50%);
        cursor: pointer;
        color: #888;
        transition: color 0.3s ease;
    }

    .toggle-password:hover {
        color: var(--purple);
    }

    /* === Custom Dropdown === */
    .custom-dropdown select {
        width: 100%;
        padding: 10px 15px;
        border: 1px solid #ccc;
        border-radius: 0.5rem;
        background-color: #f9f9f9;
        color: #333;
        transition: border-color 0.3s ease, background-color 0.3s ease;
    }

    .custom-dropdown select:focus {
        border-color: #6E6DFF;
        background-color: #fff;
        outline: none;
        box-shadow: 0 0 4px rgba(110, 109, 255, 0.5);
    }
</style>
<body>
    <!-- NAVBAR -->
    <nav>
        <div class="big-nav">
            <img class="icon" src="images/elapor-icon.png" alt="">
            <div class="content-nav">
                <section class="account">
                    <img src="images/user.png" alt="">
                        <section>
                            <h1>
                                <?php 
                                    if ($_SESSION['level'] == 'admin' || $_SESSION['level'] == 'petugas') {
                                        echo ucfirst($_SESSION['level']);
                                    }
                                ?>
                            </h1>
                            <a class="bio-class" href="bio.php">
                                <p>
                                    <?php 
                                        echo htmlspecialchars($_SESSION['nama_petugas']);
                                    ?>
                                </p>
                            </a>
                        </section>
                </section>
                <section style="margin-left: 2.5vw;" class="list-nav">
                    <li class="active-list-all"><a class="active" href="javascript:history.back()"><i class="material-icons-round">arrow_left</i> 
                        <div class="sect">
                            <h4>Back</h4>
                            <p style="font-size: 10px;">Halaman Sebelumnya</p>
                        </div>
                    </a></li>
                </section>
                <div class="button-logout">
                    <a class="logout" href="logout.php">Log Out</a>
                </div>
            </div>
        </div>
    </nav>
    <!-- CONTENT -->
    <div class="big-content">
        <div class="form-pelaporan">
            <h2>Form Pendaftaran Staff Baru</h2>
            <?php
                if (isset($_GET['status'])) {
                    $status = $_GET['status'];
                    if ($status == 'success') {
                        echo '<p style="color: green; text-align: center;">Staff baru berhasil ditambahkan!</p>';
                    } elseif ($status == 'duplicate') {
                        echo '<p style="color: red; text-align: center;">Username sudah digunakan, silakan pilih yang lain.</p>';
                    } elseif ($status == 'error') {
                        echo '<p style="color: red; text-align: center;">Terjadi kesalahan, data tidak berhasil ditambahkan.</p>';
                    }
                }
            ?>
            <form action="" method="POST">
                <!-- Input Nama Petugas -->
                <div class="form-group">
                    <label for="nama_petugas">Nama Petugas</label>
                    <input type="text" id="nama_petugas" name="nama_petugas" placeholder="Masukkan nama petugas" required>
                </div>

                <!-- Input Username -->
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="Masukkan username" required>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="password-wrapper">
                        <input type="password" id="password" name="password" placeholder="Masukkan password" required>
                        <span class="toggle-password" onclick="togglePassword()">
                            <i class="material-icons-round" id="password-icon">visibility</i>
                        </span>
                    </div>
                </div>
                                                                                
                <!-- Input Telepon -->
                <div class="form-group">
                    <label for="telp">Telepon</label>
                    <input type="text" id="telp" name="telp" placeholder="Masukkan nomor telepon" required>
                </div>

                <!-- Dropdown Level -->
                <div class="form-group">
                    <label for="level">Level</label>
                    <div class="custom-dropdown">
                        <select id="level" name="level" required>
                            <option value="admin">Admin</option>
                            <option value="petugas">Petugas</option>
                        </select>
                    </div>
                </div>

                <!-- Tombol Submit -->
                <div class="form-actions">
                    <button type="submit">Tambahkan Staff</button>
                </div>
            </form>
        </div>        
    </div>

    <script>
        function togglePassword() {
            const passwordField = document.getElementById("password");
            const passwordIcon = document.getElementById("password-icon");

            if (passwordField.type === "password") {
                passwordField.type = "text";
                passwordIcon.textContent = "visibility_off";
            } else {
                passwordField.type = "password";
                passwordIcon.textContent = "visibility";
            }
        }
    </script>
</body>
</html>