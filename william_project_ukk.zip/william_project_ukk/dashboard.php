<?php
session_start();

if (!isset($_SESSION['nik']) && !isset($_SESSION['id_petugas'])) {
    header('Location: login.php'); 
    exit();
}

if (isset($_SESSION['nik'])) {
    // MASYARAKAT
    $level = 'masyarakat';
    $user_id = $_SESSION['nik'];
    $user_name = $_SESSION['nama'];
} elseif (isset($_SESSION['id_petugas'])) {
    // PETUGAS
    $level = $_SESSION['level'] ?? ''; 
    $user_id = $_SESSION['id_petugas'];
    $user_name = $_SESSION['nama_petugas'] ?? 'Not Found';
}

if ($level == 'petugas') {
    $role = "Petugas";
    $dashboard_url = "dashboard.php";
} elseif ($level == 'admin') {
    $role = "Admin";
    $dashboard_url = "dashboard.php";
} elseif ($level == 'masyarakat') {
    $role = "Masyarakat";
    $dashboard_url = "dashboard.php";
} else {
    $role = "Pengguna Tidak Dikenal";
}

// = LEVEL by LOGIN = //
$admin_feature = ($level == 'admin');
$petugas_feature = ($level == 'petugas');
$masyarakat_feature = ($level == 'masyarakat');

include('connection.php');

// untuk menghitung jumlah laporan
$query_laporan = "SELECT COUNT(*) AS total_laporan FROM pengaduan";
$result_laporan = $connection->query($query_laporan);
$total_laporan = ($result_laporan->num_rows > 0) ? $result_laporan->fetch_assoc()['total_laporan'] : 0;

// untuk menghitung jumlah tanggapan
$query_tanggapan = "SELECT COUNT(*) AS total_tanggapan FROM tanggapan";
$result_tanggapan = $connection->query($query_tanggapan);
$total_tanggapan = ($result_tanggapan->num_rows > 0) ? $result_tanggapan->fetch_assoc()['total_tanggapan'] : 0;

// untuk menghitung jumlah akun dari tabel masyarakat dan petugas
$query_akun = "SELECT 
    (SELECT COUNT(*) FROM masyarakat) + (SELECT COUNT(*) FROM petugas) AS total_akun";
$result_akun = $connection->query($query_akun);
$total_akun = ($result_akun->num_rows > 0) ? $result_akun->fetch_assoc()['total_akun'] : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="images/elapor-xicon.png">
    <title>DASHBOARD E-LAPOR | DASHBOARD LAYANAN PELAPORAN MASYARAKAT</title>
</head>
<style>
    /* === E - LAPOR ROOT === */
    @import url('https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap');

    :root {
        --black: #34495E;
        --dark: #1D1A39;
        --purple-dark: #451952;
        --purple: #7324c7;
        --red-dark: #862549;
        --pink-lilac: #AE445A;
        --yellow: #F39F5A;
        --white-gray: #E8BCB9;
    }

    * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
        text-decoration: none;
        list-style: none;
        font-family: 'Nunito';
        color: var(--black);
    }

    body {
        background-color: #f1f2f7;
    }

    html {
        scroll-behavior: smooth;
    }

    ::-webkit-scrollbar {
        width: 12px;
    }

    ::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }

    ::-webkit-scrollbar-thumb {
        background: var(--purple);
        border-radius: 10px;
        border: 2px solid #f1f1f1;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: var(--purple-dark);
    }

    /* = NAVBAR = */
    nav {
        width: 18vw;
        height: 100vh;
        position: fixed;
        background-color: #f1f2f7;
        padding-bottom: 8vh;
    }

    .big-nav {
        border-right: 2px solid #d3d3d388;
        height: 100%;
    }

    .account {
        display: flex;
        align-items: center;
        flex-direction: column;
        justify-content: center;
        text-align: center;
        gap: 13px;
        margin: 4vh 0px 11vh 0px;
    }

    .bio-class:hover {
        text-decoration: underline;
    }

    .icon{
        width: 30%;
        margin-left: 2.5vw;
        padding-top: 1.7vh;
        color: var(--purple-dark);
        text-transform: uppercase;
    }
    .account img {
        width: 45%;
        border-radius: 50%;
        background-color: #C9B6F2;
        margin-top: 2vh;
    }
    .account section h1 {
        font-size: 20px;
        font-weight: bolder;
        margin: -1px 0;
    }
    .account section p {
        font-size: 11px;
        width: 220px;
        transition: all .3s ease-in-out;
    }
    .account section p:hover {
        color: #6c7b87;
    }

    .list-nav a {
        text-align: left;
        display: flex;
        align-items: center;
        gap: 20px;
        margin: 15px 0px;
    }

    .list-nav a i {
        background-color: white;
        color: gray;
        padding: 7px;
        border-radius: 12px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.01);
    }

    .list-nav a.active i {
        background-color: var(--purple);
        color: white;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .list-nav a.active h4, .list-nav a.active p {
        color: var(--purple);
    }

    .list-nav li {
        transform: scale(1);
        transition: all 0.3s ease-in-out;
    }
    .list-nav li:hover {
        transform: scale(1.01);
    }

    .button-logout {
        margin-top: 20vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    <?php if ($masyarakat_feature || $petugas_feature): ?>
        .list-nav a {
            margin: 17px 10px;
        }
        .button-logout {
            margin-top: 27vh;
        }
    <?php endif; ?>

    .logout {
        display: flex;
        justify-content: center;
        align-items: center;
        font-weight: bold;
        background-color: var(--purple);
        color: white;
        font-size: 14px;
        padding: 10px 20px;
        width: 40%;
        max-width: 200px;
        border-radius: 7px;
        transition: all 0.3s ease-in-out;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        cursor: pointer;
    }

    .logout:hover {
        background-color: var(--yellow);
        color: var(--dark);
        box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
        transform: scale(1.05);
    }

    /* = CONTENT = */
    .big-content {
        margin: 4vh 0 4vh 20.5vw;
        width: 76.5vw;
        height: 100%;
        display: flex;
        flex-direction: column;
        gap: 25px;
        background-color: #f9fafe;
        border-radius: 20px;
        padding: 30px;
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
    }

    .dashboard-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        background-color: white;
        padding: 35px;
        height: 25vh;
        border-radius: 20px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        position: relative;
    }

    .dashboard-header h1 {
        font-size: 24px;
        color: var(--purple-dark);
        font-weight: bold;
    }

    .dashboard-header img {
        width: 120px;
        height: auto;
        border-radius: 50%;
        position: absolute;
        right: 40px;
        top: -30px;
    }

    .dashboard-header a {
        text-transform: uppercase;
        background-color: var(--purple);
        color: white;
        padding: 10px 20px;
        border-radius: 15px;
        font-weight: bold;
        transition: all 0.3s ease;
    }

    .dashboard-header a:hover {
        background-color: var(--yellow);
        color: var(--dark);
        transform: scale(1.05);
    }

    /* KARTU RINGKASAN */
    .summary-cards {
        display: flex;
        justify-content: space-between;
        gap: 20px;
    }

    .card {
        flex: 1;
        background-color: white;
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        text-align: center;
        transition: all 0.3s ease;
    }

    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
    }

    .card h2 {
        font-size: 20px;
        color: var(--purple-dark);
    }

    .card p {
        font-size: 16px;
        font-weight: bold;
        margin-top: 10px;
        color: var(--dark);
    }

    /* NOTIFIKASI */
    .notifications {
        background-color: white;
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        margin-top: 20px;
    }

    .notifications h3 {
        color: var(--purple-dark);
        font-size: 18px;
        margin-bottom: 15px;
        text-transform: uppercase;
    }

    .notification-item {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 10px;
    }

    .notification-item i {
        color: var(--yellow);
        background-color: #fef4e8;
        padding: 8px;
        border-radius: 50%;
    }

    .notification-item p {
        font-size: 14px;
        color: var(--dark);
    }
</style>
<body>
    <!-- NAVBAR -->
    <nav>
        <div class="big-nav">
            <img class="icon" src="images/elapor-icon.png" alt="">
            <div class="content-nav">
                <section class="account">
                    <img src="images/user.png" alt="">
                    <section>
                        <h1><?php echo $role; ?></h1>
                        <a class="bio-class" href="bio.php"><p><?php echo htmlspecialchars($user_name); ?></p></a>
                    </section>
                </section>
                <section style="margin-left: 2.5vw;" class="list-nav">
                    <li class="active-list-all"><a class="active" href="dashboard.php"><i class="material-icons-round">dashboard</i> 
                        <div class="sect">
                            <h4>Dashboard</h4>
                            <p style="font-size: 10px;">Laman Utama</p>
                        </div>
                    </a></li>
                    
                    <?php if ($masyarakat_feature): ?>
                        <li><a href="laporan-ku.php"><i class="material-icons-round">description</i>
                            <div class="sect">
                                <h4>Laporanku</h4>
                                <p style="font-size: 10px;">Laporan Anda</p>
                            </div>
                        </a></li>
                    <?php endif; ?>

                    <?php if ($admin_feature || $petugas_feature): ?>
                        <li><a href="list-laporan.php"><i class="material-icons-round">description</i>
                            <div class="sect">
                                <h4>List Laporan</h4>
                                <p style="font-size: 10px;">Laporan Masuk</p>
                            </div>
                        </a></li>
                    <?php endif; ?>

                    <?php if ($admin_feature): ?>
                        <li><a href="list-account.php"><i class="material-icons-round">people</i>
                            <div class="sect">
                                <h4>List Account</h4>
                                <p style="font-size: 10px;">Manajemen Akun</p>
                            </div>
                        </a></li>
                    <?php endif; ?>
                </section>
                <div class="button-logout">
                    <a class="logout" href="logout.php">Log Out</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- CONTENT -->
    <div class="big-content">
        <!-- Header -->
        <div class="dashboard-header">
            <div>
                <h1 id="greeting">Good Morning</h1>
                <p>What are we doing today?</p>
            </div>
            <section>
                <?php if ($admin_feature || $petugas_feature): ?>
                    <a href="list-laporan.php">MANAGE LAPORAN</a>
                <?php endif; ?>
                <?php if ($masyarakat_feature): ?>
                    <a href="laporan-ku.php">LAPORAN KU</a>
                <?php endif; ?>
            </section>
        </div>

        <!-- Summary Cards -->
        <div class="summary-cards">
            <div class="card">
                <h2>Jumlah Laporan</h2>
                <p style="margin-top: -2px; font-size: 13px; font-weight: 300;">(Hingga hari ini)</p>
                <p><?php echo $total_laporan; ?></p>
            </div>
            <div class="card">
                <h2>Jumlah Tanggapan</h2>
                <p style="margin-top: -2px; font-size: 13px; font-weight: 300;">(Hingga hari ini)</p>
                <p><?php echo $total_tanggapan; ?></p>
            </div>
            <div class="card">
                <h2>Jumlah Akun</h2>
                <p style="margin-top: -2px; font-size: 13px; font-weight: 300;">(Hingga hari ini)</p>
                <p><?php echo $total_akun; ?></p>
            </div>
        </div>

        <!-- Notifications -->
        <div class="notifications">
            <h3>Notifications</h3>
            <div class="notification-item">
                <i class="material-icons-round">notifications</i>
                <p>You do not have any notifications.</p>
            </div>
            <div class="notification-item">
                <i class="material-icons-round">error_outline</i>
                <p>Some reports have not been resolved.</p>
            </div>
            <div class="notification-item">
                <i class="material-icons-round">calendar_today</i>
                <p id="realtime-date">Loading...</p>
            </div>
        </div>
    </div>

    <script>
        function updateGreeting() {
            var now = new Date();
            var hour = now.getHours();
            var greeting = '';

            if (hour >= 5 && hour < 12) {
                greeting = 'Good Morning'; // Pagi
            } else if (hour >= 12 && hour < 18) {
                greeting = 'Good Afternoon'; // Siang
            } else if (hour >= 18 && hour < 21) {
                greeting = 'Good Evening'; // Sore
            } else {
                greeting = 'Good Night'; // Malam
            }

            document.getElementById('greeting').innerText = greeting;
        }
        window.onload = updateGreeting;

        function updateDateTime() {
            const dateElement = document.getElementById('realtime-date');
            const now = new Date();

            const options = { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric', 
                hour: '2-digit', 
                minute: '2-digit',
                hour12: false
            };
            
            const formattedDate = now.toLocaleDateString('en-US', options);
            dateElement.innerText = `Today is ${formattedDate}`;
        }
        updateDateTime();
        setInterval(updateDateTime, 1000);
    </script>
</body>
</html>
