<?php
session_start();

if (isset($_SESSION['nik'])) {
    unset($_SESSION['nik']);
} elseif (isset($_SESSION['id_petugas'])) {
    unset($_SESSION['id_petugas']);
}

header('Location: login.php');
exit();
?>
