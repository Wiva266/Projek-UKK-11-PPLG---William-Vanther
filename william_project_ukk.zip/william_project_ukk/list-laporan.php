<?php
session_start();
require 'connection.php';

if (!isset($_SESSION['id_petugas'])) {
    header('Location: login.php');
    exit();
}

include('connection.php');

$statusFilter = isset($_GET['status']) ? $_GET['status'] : 'all';
$searchQuery = isset($_GET['search']) ? mysqli_real_escape_string($connection, $_GET['search']) : '';
$searchCondition = $searchQuery ? "AND (p.isi_laporan LIKE '%$searchQuery%' OR p.nik LIKE '%$searchQuery%')" : '';
$statusCondition = ($statusFilter !== 'all') ? "AND p.status LIKE '%$statusFilter%'" : '';

$query = "
    SELECT p.id_pengaduan, p.nik, p.tgl_pengaduan, p.isi_laporan, p.status, 
           t.id_tanggapan, t.tgl_tanggapan, t.tanggapan, t.id_petugas
    FROM pengaduan p
    LEFT JOIN tanggapan t ON p.id_pengaduan = t.id_pengaduan
    WHERE 1=1 $statusCondition $searchCondition
";
$result = mysqli_query($connection, $query);
$dataLaporan = mysqli_fetch_all($result, MYSQLI_ASSOC);

function limitTextToWords($text, $wordLimit) {
    $words = explode(' ', $text);
    return count($words) > $wordLimit 
        ? implode(' ', array_slice($words, 0, $wordLimit)) . ' ...' 
        : $text;
}

function getStatusText($status) {
    switch ($status) {
        case '0': return 'Belum Ditanggapi';
        case 'proses': return 'Sedang Diproses';
        case 'selesai': return 'Sudah Ditanggapi';
        default: return 'Tidak Diketahui';
    }
}
mysqli_close($connection);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="images/elapor-xicon.png">
    <title>LIST LAPORAN E-LAPOR | DASHBOARD LAYANAN PELAPORAN MASYARAKAT</title>
</head>
<style>
    /* === E - LAPOR ROOT === */
    @import url('https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap');

    :root {
        --black: #34495E;
        --dark: #1D1A39;
        --purple-dark: #451952;
        --purple: #7324c7;
        --red-dark: #862549;
        --pink-lilac: #AE445A;
        --yellow: #F39F5A;
        --white-gray: #E8BCB9;
    }

    * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
        text-decoration: none;
        list-style: none;
        font-family: 'Nunito';
        color: var(--black);
    }

    body {
        background-color: #f1f2f7;
    }

    html {
        scroll-behavior: smooth;
    }

    ::-webkit-scrollbar {
        width: 12px;
    }

    ::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }

    ::-webkit-scrollbar-thumb {
        background: var(--purple);
        border-radius: 10px;
        border: 2px solid #f1f1f1;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: var(--purple-dark);
    }

    /* = NAVBAR = */
    nav {
        width: 18vw;
        height: 100vh;
        position: fixed;
        background-color: #f1f2f7;
        padding-bottom: 8vh;
    }

    .big-nav {
        border-right: 2px solid #d3d3d388;
        height: 100%;
    }

    .account {
        display: flex;
        align-items: center;
        flex-direction: column;
        justify-content: center;
        text-align: center;
        gap: 13px;
        margin: 4vh 0px 11vh 0px;
    }

    .bio-class:hover {
        text-decoration: underline;
    }

    .icon{
        width: 30%;
        margin-left: 2.5vw;
        padding-top: 1.7vh;
        color: var(--purple-dark);
        text-transform: uppercase;
    }
    .account img {
        width: 45%;
        border-radius: 50%;
        background-color: #C9B6F2;
        margin-top: 2vh;
    }
    .account section h1 {
        font-size: 20px;
        font-weight: bolder;
        margin: -1px 0;
    }
    .account section p {
        font-size: 11px;
        width: 220px;
        transition: all .3s ease-in-out;
    }
    .account section p:hover {
        color: #6c7b87;
    }

    .list-nav a {
        text-align: left;
        display: flex;
        align-items: center;
        gap: 20px;
        margin: 15px 0px;
    }

    .list-nav a i {
        background-color: white;
        color: gray;
        padding: 7px;
        border-radius: 12px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.01);
    }

    .list-nav a.active i {
        background-color: var(--purple);
        color: white;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .list-nav a.active h4, .list-nav a.active p {
        color: var(--purple);
    }

    .list-nav li {
        transform: scale(1);
        transition: all 0.3s ease-in-out;
    }
    .list-nav li:hover {
        transform: scale(1.01);
    }

    <?php if ($_SESSION['level'] == 'petugas') : ?>
        .button-logout {
            margin-top: 27vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .list-nav a {
            margin: 17px 10px;
        }
    <?php endif; ?>

    <?php if ($_SESSION['level'] == 'admin') : ?>
        .button-logout {
            margin-top: 20vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
    <?php endif; ?>

    .logout {
        background-color: var(--purple);
    }
    .tanggap {
        background-color: var(--yellow);
        margin-bottom: 5px;
    }
    .status-select {
        background-color: var(--pink-lilac);
        border: transparent;
    }

    .logout, .tanggap, .status-select {
        display: flex;
        justify-content: center;
        align-items: center;
        font-weight: bold;
        color: white;
        font-size: 14px;
        padding: 10px 20px;
        max-width: 200px;
        border-radius: 7px;
        transition: all 0.3s ease-in-out;
        cursor: pointer;
    }

    .logout:hover {
        background-color: var(--yellow);
        color: var(--dark);
        box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
        transform: scale(1.05);
    }
    .tanggap:hover, .status-select:hover {
        color: black;
        opacity: 0.8;
    }

    /* = CONTENT = */
    .big-content {
        margin: 4vh 0 4vh 20.5vw;
        width: 76.5vw;
        height: 92vh;
    }

    .dashboard-header {
        background-color: white;
        padding: 35px;
        border-radius: 25px;
        position: relative;
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
    }

    /* = TABS NAVIGATION = */
    .tabs {
        display: flex;
        margin-top: 20px;
        margin-left: 1px;
        gap: 10px;
    }

    .tab-btn {
        padding: 10px 20px;
        background-color: #fff;
        color: #333;
        border: 1px solid #ddd;
        border-radius: 5px;
        font-size: 14px;
        font-weight: bold;
        cursor: pointer;
        transition: background-color 0.3s, color 0.3s;
    }

    .tab-btn:hover {
        border: 1px solid var(--purple);
        background-color: white;
        color: var(--purple);
    }

    .tab-btn.active {
        background-color: var(--purple);
        color: #fff;
        border-color: var(--purple);
    }

    .table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    #unansweredReportsTable, #answeredReportsTable {
        display: none;
    }

    .search-container {
        display: flex;
        align-items: center;
        position: relative;
        width: 100%;
        margin-top: 2vh;
    }

    #searchInput {
        width: 100%;
        padding: 10px 15px 10px 45px;
        font-size: 14px;
        border: 1px solid #ddd;
        border-radius: 25px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        background-color: #f9f9f9;
        transition: all 0.3s ease-in-out;
    }

    #searchInput:focus {
        outline: none;
        border-color: var(--purple);
        box-shadow: 0 3px 6px rgba(115, 36, 199, 0.2);
    }

    .search-icon {
        position: absolute;
        left: 15px;
        font-size: 20px;
        color: var(--purple);
        pointer-events: none;
    }

    /* = CONTENT = */
    .table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        color: #333;
    }

    .table thead th {
        font-weight: bold;
        text-align: left;
        padding: 10px 15px;
        border-bottom: 2px solid #E0E0E0;
        color: #666;
        font-size: 12px;
        text-transform: uppercase;
    }

    .table tbody tr {
        border-bottom: 1px solid #E0E0E0;
    }

    .table tbody tr:hover {
        background-color: #F3F3F3;
    }

    .table td {
        padding: 10px 15px;
        font-size: 14px;
        vertical-align: middle;
        color: #333;
    }

    .detail:hover {
        text-decoration: underline;
    }

    /* Pagination styling */
    .pagination {
        margin: 20px 0;
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 10px;
    }

    .pagination button {
        padding: 8px 16px;
        font-size: 14px;
        border: 1px solid #E0E0E0;
        background-color: #FFF;
        color: #333;
        cursor: pointer;
        border-radius: 4px;
        transition: all 0.3s ease;
    }

    .pagination button:hover {
        background-color: #F3F3F3;
    }

    .pagination button.active {
        background-color: var(--purple);
        color: #FFF;
        border-color: var(--purple);
    }

    .pagination button.disabled {
        cursor: not-allowed;
        opacity: 0.6;
    }

    @media (max-width: 768px) {
        .table thead th, .table td {
            padding: 8px 10px;
        }

        .pagination button {
            font-size: 12px;
            padding: 6px 12px;
        }
    }
</style>
<body>
    <!-- NAVBAR -->
    <nav>
        <div class="big-nav">
            <img class="icon" src="images/elapor-icon.png" alt="">
            <div class="content-nav">
                <section class="account">
                    <img src="images/user.png" alt="">
                    <section>
                        <h1>
                            <?php
                            if ($_SESSION['level'] == 'admin') {
                                echo 'Admin';
                            } elseif ($_SESSION['level'] == 'petugas') {
                                echo 'Petugas';
                            } else {
                                echo 'Level Tidak Dikenal'; 
                            }
                            ?>
                        </h1>                        
                        <a class="bio-class" href="bio.php"><p><?php echo $_SESSION['nama_petugas'];?></p></a>
                    </section>
                </section>
                <section style="margin-left: 2.5vw;" class="list-nav">
                    <li><a href="dashboard.php"><i class="material-icons-round">dashboard</i> 
                        <div class="sect">
                            <h4>Dashboard</h4>
                            <p style="font-size: 10px;">Laman Utama</p>
                        </div>
                    </a></li>
                    <li class="active-list-all"><a class="active" href="list-laporan.php"><i class="material-icons-round">description</i>
                        <div class="sect">
                            <h4>List Laporan</h4>
                            <p style="font-size: 10px;">Laporan Masuk</p>
                        </div>
                    </a></li>
                    <?php if ($_SESSION['level'] == 'admin') : ?>
                        <li><a href="list-account.php"><i class="material-icons-round">people</i>
                            <div class="sect">
                                <h4>List Account</h4>
                                <p style="font-size: 10px;">Manajemen Akun</p>
                            </div>
                        </a></li>
                    <?php endif; ?>
                </section>
                <div class="button-logout">
                    <a class="logout" href="logout.php">Log Out</a>
                </div>
            </div>
        </div>
    </nav>
    <!-- CONTENT -->
    <div class="big-content">
        <div class="dashboard-header">
            <h1>LIST LAPORAN</h1>
            <p>Daftar Semua Laporan</p>
            <div class="tabs">
                <?php if ($_SESSION['level'] == 'admin') : ?>
                    <a href="generate-laporan.php" class="tab-btn">Generate Laporan</a>
                <?php endif; ?>
            </div>
        </div>
        <!-- TAB NAVIGATION DAN SEARCH -->
        <div class="tabs-container">
            <div class="tabs">
                <button onclick="filterReports('all')" class="tab-btn active">Semua Laporan</button>
                <button onclick="filterReports('0')" class="tab-btn">Belum Ditanggapi</button>
                <button onclick="filterReports('proses')" class="tab-btn">Sedang Diproses</button>
                <button onclick="filterReports('selesai')" class="tab-btn">Sudah Ditanggapi</button>
            </div>
            <div class="search-container">
                <i class="material-icons-round search-icon">search</i>
                <input type="text" id="searchInput" placeholder="Cari laporan..." oninput="searchReports()">
            </div>
        </div>

        <!-- TABEL LAPORAN -->
        <div class="tabel-data">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID Laporan</th>
                        <th>NIK Pelapor</th>
                        <th>Isi Laporan</th>
                        <th>Tanggal Laporan</th>
                        <th>Tanggal Tanggapan</th>
                        <th>ID Petugas</th>
                        <th>Status</th>
                        <th style="text-align: center;">More</th>
                        <th style="text-align: center;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($dataLaporan as $laporan) : ?>
                        <tr data-status="<?= htmlspecialchars($laporan['status']); ?>">
                            <td><?= htmlspecialchars($laporan['id_pengaduan']); ?></td>
                            <td><?= htmlspecialchars($laporan['nik']); ?></td>
                            <td><?= htmlspecialchars(limitTextToWords($laporan['isi_laporan'], 10)); ?></td>
                            <td><?= htmlspecialchars($laporan['tgl_pengaduan']); ?></td>
                            <td><?= htmlspecialchars($laporan['tgl_tanggapan'] ?: 'Belum Ditanggapi'); ?></td>
                            <td><?= htmlspecialchars($laporan['id_petugas'] ?: 'Belum Ditanggapi'); ?></td>
                            <td><?= htmlspecialchars(getStatusText($laporan['status'])); ?></td>
                            <td>
                                <a class="detail" href="form-check-laporan.php?id=<?= urlencode($laporan['id_pengaduan']); ?>">Detail</a>
                            </td>
                            <td>
                                <section>
                                    <?php if ($laporan['status'] === '0' || $laporan['status'] === 'proses' ) : ?>
                                        <a class="tanggap" href="form-penanggapan.php?id=<?= urlencode($laporan['id_pengaduan']); ?>">Tanggapan</a>
                                    <?php else : ?>
                                        <a class="tanggap disabled" href="#" style="pointer-events: none; background-color: gray;">Tanggapan</a>
                                    <?php endif; ?>
                                </section>
                                <form action="update-status.php" method="POST">
                                    <input type="hidden" name="id_pengaduan" value="<?= htmlspecialchars($laporan['id_pengaduan']); ?>">
                                    <section>
                                        <select name="status" class="status-select" onchange="this.form.submit()">
                                            <option value="" disabled selected>Status</option>
                                            <option value="proses" <?= $laporan['status'] == 'proses' ? 'selected' : '' ?>>Proses</option>
                                            <option value="selesai" <?= $laporan['status'] == 'selesai' ? 'selected' : '' ?>>Selesai</option>
                                        </select>
                                    </section>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- SCRIPT -->
    <script>
        function submitForm() {
            document.getElementById('statusForm').submit();
        }

        function filterReports(status) {
            const rows = document.querySelectorAll("tbody tr");

            rows.forEach(row => {
                const rowStatus = row.getAttribute("data-status");
                if (status === "all" || rowStatus === status) {
                    row.style.display = "";
                } else {
                    row.style.display = "none";
                }
            });

            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
        }

        function searchReports() {
            const input = document.getElementById("searchInput").value.toLowerCase();
            const rows = document.querySelectorAll("tbody tr"); 

            rows.forEach(row => {
                const columns = row.querySelectorAll("td");
                let found = false;

                columns.forEach(column => {
                    if (column.textContent.toLowerCase().includes(input)) { 
                        found = true;
                    }
                });
                row.style.display = found ? "" : "none";
            });
        }
    </script>
</body>
</html>
