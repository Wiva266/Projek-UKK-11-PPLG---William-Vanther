<?php
session_start();
require 'connection.php';

if (!isset($_SESSION['id_petugas'])) {
    header('Location: login.php');
    exit();
}

if (isset($_POST['id_pengaduan'], $_POST['status'])) {
    $id_pengaduan = mysqli_real_escape_string($connection, $_POST['id_pengaduan']);
    $status = mysqli_real_escape_string($connection, $_POST['status']);

    $query = "UPDATE pengaduan SET status = '$status' WHERE id_pengaduan = '$id_pengaduan'";
    if (mysqli_query($connection, $query)) {
        $_SESSION['success'] = "Status laporan berhasil diperbarui!";
    } else {
        $_SESSION['error'] = "Gagal memperbarui status. Silakan coba lagi.";
    }
}

header('Location: list-laporan.php');
exit();
?>
