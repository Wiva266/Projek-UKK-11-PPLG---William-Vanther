<?php
include 'connection.php';

session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nik = $_POST['nik'];
    $password = $_POST['password'];
    $login_as = $_POST['login_as'];

    // MASYARAKAT
    if (empty($nik) || empty($password)) {
        $error = "NIK dan Password harus diisi!";
    } else {
        if ($login_as == 'masyarakat') {
            $query = "SELECT * FROM masyarakat WHERE nik = ?";
            $stmt = $connection->prepare($query);
            $stmt->bind_param('s', $nik);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();

                if (md5($password) === $user['password']) {
                    $_SESSION['nik'] = $user['nik'];
                    $_SESSION['nama'] = $user['nama'];
                    $_SESSION['username'] = $user['username'];
                    header('Location: dashboard.php');
                    exit();
                } else {
                    $error = "Password salah!";
                }
            } else {
                $error = "NIK tidak ditemukan!";
            }
        }

        // ADMIN
        elseif ($login_as == 'admin') {
            $query = "SELECT * FROM petugas WHERE id_petugas = ?";
            $stmt = $connection->prepare($query);
            $stmt->bind_param('s', $nik);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $admin = $result->fetch_assoc();

                if (md5($password) === $admin['password']) {
                    $_SESSION['id_petugas'] = $admin['id_petugas'];
                    $_SESSION['level'] = $admin['level'];
                    $_SESSION['nama_petugas'] = $admin['nama_petugas'];
                    header('Location: dashboard.php');
                    exit();
                } else {
                    $error = "Password salah!";
                }
            } else {
                $error = "ID Petugas tidak ditemukan!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=horizontal_rule" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="icon" type="image/x-icon" href="images/elapor-xicon.png">
    <title>LOGIN E-LAPOR | DASHBOARD LAYANAN PELAPORAN MASYARAKAT</title>
</head>
<style>
    /* === E - LAPOR ROOT === */
    @import url('https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap');

    :root {
        --black: #34495E;
        --dark: #1D1A39;
        --purple-dark: #451952;
        --purple: #7324c7;
        --red-dark: #862549;
        --pink-lilac: #AE445A;
        --yellow: #F39F5A;
        --white-gray: #E8BCB9;
    }

    * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
        text-decoration: none;
        list-style: none;
        font-family: 'Nunito';
        color: var(--black);
    }

    body {
        position: relative;
        min-height: 100vh;
        margin: 0;
    }

    body::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: url(images/texture-formloginreg.png) center/cover no-repeat;
        opacity: 0.2;
        z-index: -1;
    }

        html {
        scroll-behavior: smooth;
    }

    ::-webkit-scrollbar {
        width: 12px;
    }

    ::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }

    ::-webkit-scrollbar-thumb {
        background: var(--purple);
        border-radius: 10px;
        border: 2px solid #f1f1f1;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: var(--purple-dark);
    }

    /* = TITLE COLOR = */
    .title-to-combine {
        display: flex;
        gap: 6.5px;
    }
    .coloring-sub {
        color: var(--purple);
    }

    /* = LOGIN FORM = */
    .big-login {
        width: 100vw;
        height: 100vh;

        display: flex;
        justify-content: center;
        align-items: center;
    }

    .login {
        width: 70%;
        height: 75%;
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: 25px;
        background-color: rgba(255, 255, 255, 0.909);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .img-side {
        width: 51.5%;
        padding: 5vw;
        border-radius: 25px;
        background-color: var(--purple);
    }

    .form-login {
        width: 50%;
        display: flex;
        justify-content: center;
        padding: 100px;
    }

    .form-login, .form-login section {
        display: flex;
        justify-content: center;
        flex-direction: column;
    }

    .input-container {
        display: flex;
        flex-direction: column;
        gap: 15px;
        width: 100%;
        max-width: 400px;
        margin: 7vh 0;
    }

    .input-container input {
        width: 100%;
        padding: 12px 15px;
        border: 1px solid #ddd;
        border-radius: 5px; 
        font-size: 16px;
        color: #333;
        outline: none;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    .input-container input::placeholder {
        color: #aaa;
        font-size: 14px;
    }

    .input-container input:focus {
        border-color: #7324c7;
        box-shadow: 0 0 5px rgba(115, 36, 199, 0.3);
    }

    .select-to-log-or-reg {
        display: flex;
        align-items: center;
        gap: 5px;
        font-size: 15px;
        padding: 5px 2px;
    }

    .select-to-log-or-reg a {
        color: var(--purple);
        text-decoration: none;
        position: relative;
        overflow: hidden;
    }

    .select-to-log-or-reg a::before {
        content: '';
        position: absolute;
        bottom: 0;
        left: -100%;
        width: 100%;
        height: 2px;
        background-color: var(--purple);
        transition: left 0.3s ease;
    }

    .select-to-log-or-reg a:hover::before {
        left: 0;
    }

    .submit-to-dashboard {
        background-color: var(--purple);
        display: flex;
        align-items: center;
        text-align: center;
        justify-content: center;
        padding: 10px 20px;
        border-radius: 7px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        text-decoration: none;
        transition: all 0.3s ease;

        width: 100%;
        border: none;
        color: white;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        cursor: pointer;
    }

    .submit-to-dashboard:hover {
        background-color: #7c39b3;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        transform: scale(1.01);
    }

    .submit-as-admin, .submit-as-admin button, .submit-as-admin p {
        display: flex;
        align-items: center;
        text-align: center;
        justify-content: center;
        margin: 5px 0;
    }

    .submit-as-admin button {
        background-color: transparent;
        border-radius: 7px;
        text-decoration: none;
        transition: all 0.3s ease;

        width: 100%;
        border: none;
        font-weight: bold;
        text-transform: uppercase;
        cursor: pointer;
        color: var(--purple);
        transform: scale(1);
    }
    .submit-as-admin button:hover {
        color: var(--purple-dark);
        transform: scale(1.01);
    }

    .toggle-password {
        cursor: pointer;
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
    }

    .toggle-password i {
        color: var(--purple);
    }

    .message {
        font-size: .9rem;
        font-weight: bold;
        margin-top: 15px;
        text-align: center;
        padding: 7px;
        border-radius: 5px;
    }
    .success {
        color: #ffffff;
        background-color: #6a0dad;
    }
    .error {
        color: #ffffff;
        background-color: #d32f2f;
    }
</style>
<body>
    <div class="big-login">
        <div class="login">
            <img class="img-side" src="images/login-register.png" alt="login-img">
            <section class="form-login">
                <img style="width: 20vw;" src="images/elapor-icon.png" alt="">
                <?php if (isset($error)): ?>
                    <p class="message error"><?= htmlspecialchars($error); ?></p>
                <?php endif; ?>
                <form method="POST" action="">
                    <section class="input-container">
                        <input type="text" id="nik" name="nik" placeholder="Your NIK / ID" required>
                        <div style="position: relative;">
                            <input type="password" id="password" name="password" placeholder="Your Password" required>
                            <span class="toggle-password" onclick="togglePassword()">
                                <i class="fas fa-eye" id="eye-icon"></i>
                            </span>
                        </div>
                    </section>

                    <div class="select-to-log-or-reg">
                        <p>Don't have an account?</p>
                        <a href="register.php">Register</a>
                    </div>

                    <!-- Tombol untuk login sebagai masyarakat -->
                    <button class="submit-to-dashboard" type="submit" name="login_as" value="masyarakat">Sign In</button>
                    
                    <section class="submit-as-admin">
                        <p style="color: gray;">
                            <span style="color: gray;" class="material-symbols-outlined">horizontal_rule</span>
                            Or
                            <span style="color: gray;" class="material-symbols-outlined">horizontal_rule</span>
                        </p>
                        <!-- Tombol untuk login sebagai admin -->
                        <button type="submit" name="login_as" value="admin">Sign In as Staff</button>
                    </section>
                </form>
            </section>
        </div>
    </div>

    <script>
        function togglePassword() {
            var passwordField = document.getElementById("password");
            var eyeIcon = document.getElementById("eye-icon");

            if (passwordField.type === "password") {
                passwordField.type = "text";
                eyeIcon.classList.remove("fa-eye");
                eyeIcon.classList.add("fa-eye-slash");
            } else {
                passwordField.type = "password";
                eyeIcon.classList.remove("fa-eye-slash");
                eyeIcon.classList.add("fa-eye");
            }
        }
    </script>
</body>
</html>
