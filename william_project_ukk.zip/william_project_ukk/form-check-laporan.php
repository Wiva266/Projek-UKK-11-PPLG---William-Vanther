<?php
session_start();
include('connection.php');

if (!isset($_SESSION['username']) && !isset($_SESSION['nik'])) {
    header('Location: login.php');
    exit();
}

if (isset($_SESSION['nik'])) {
    $nama_user = $_SESSION['nama'];
    $level_user = 'Masyarakat';
} else {
    $nama_user = $_SESSION['nama_petugas'];
    if ($_SESSION['level'] == 'admin') {
        $level_user = 'Admin';
    } elseif ($_SESSION['level'] == 'petugas') {
        $level_user = 'Petugas';
    } else {
        $level_user = 'Tidak Diketahui';
    }
}

if (isset($_GET['id'])) {
    $id_pengaduan = mysqli_real_escape_string($connection, $_GET['id']);
    $query = "
    SELECT p.id_pengaduan, p.nik, p.isi_laporan, p.tgl_pengaduan, p.foto, 
           t.tgl_tanggapan, t.tanggapan, p.status,
           m.nama AS nama_pelapor, pt.id_petugas AS no_petugas, pt.nama_petugas AS nama_staff
    FROM pengaduan p
    LEFT JOIN tanggapan t ON p.id_pengaduan = t.id_pengaduan
    LEFT JOIN masyarakat m ON p.nik = m.nik
    LEFT JOIN petugas pt ON t.id_petugas = pt.id_petugas
    WHERE p.id_pengaduan = '$id_pengaduan'";
    $result = mysqli_query($connection, $query);
    $laporanDetail = mysqli_fetch_assoc($result);

    if (!$laporanDetail) {
        die("Laporan tidak ditemukan");
    }
} else {
    die("ID laporan tidak valid");
}

mysqli_close($connection);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="images/elapor-xicon.png">
    <title>FORM CEK PELAPORAN E-LAPOR | DASHBOARD LAYANAN PELAPORAN MASYARAKAT</title>
</head>
<style>
    /* === E - LAPOR ROOT === */
    @import url('https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap');

    :root {
        --black: #34495E;
        --dark: #1D1A39;
        --purple-dark: #451952;
        --purple: #7324c7;
        --red-dark: #862549;
        --pink-lilac: #AE445A;
        --yellow: #F39F5A;
        --white-gray: #E8BCB9;
    }

    * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
        text-decoration: none;
        list-style: none;
        font-family: 'Nunito';
        color: var(--black);
    }

    body {
        background-color: #f1f2f7;
    }

    html {
        scroll-behavior: smooth;
    }

    ::-webkit-scrollbar {
        width: 12px;
    }

    ::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }

    ::-webkit-scrollbar-thumb {
        background: var(--purple);
        border-radius: 10px;
        border: 2px solid #f1f1f1;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: var(--purple-dark);
    }

    /* = NAVBAR = */
    nav {
        width: 18vw;
        height: 100vh;
        position: fixed;
        background-color: #f1f2f7;
        padding-bottom: 8vh;
    }

    .big-nav {
        border-right: 2px solid #d3d3d388;
        height: 100%;
    }

    .account {
        display: flex;
        align-items: center;
        flex-direction: column;
        justify-content: center;
        text-align: center;
        gap: 13px;
        margin: 4vh 0px 11vh 0px;
    }

    .bio-class:hover {
        text-decoration: underline;
    }

    .icon{
        width: 30%;
        margin-left: 2.5vw;
        padding-top: 1.7vh;
        color: var(--purple-dark);
        text-transform: uppercase;
    }
    .account img {
        width: 45%;
        border-radius: 50%;
        background-color: #C9B6F2;
        margin-top: 2vh;
    }
    .account section h1 {
        font-size: 20px;
        font-weight: bolder;
        margin: -1px 0;
    }
    .account section p {
        font-size: 11px;
        width: 220px;
        transition: all .3s ease-in-out;
    }
    .account section p:hover {
        color: #6c7b87;
    }

    .list-nav a {
        text-align: left;
        display: flex;
        align-items: center;
        gap: 20px;
        margin: 15px 0px;
    }

    .list-nav a i {
        background-color: white;
        color: gray;
        padding: 7px;
        border-radius: 12px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.01);
    }

    .list-nav a.active i {
        background-color: var(--purple);
        color: white;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .list-nav a.active h4, .list-nav a.active p {
        color: var(--purple);
    }

    .list-nav li {
        transform: scale(1);
        transition: all 0.3s ease-in-out;
    }
    .list-nav li:hover {
        transform: scale(1.01);
    }

    .button-logout {
        margin-top: 35vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .logout {
        display: flex;
        justify-content: center;
        align-items: center;
        font-weight: bold;
        background-color: var(--purple);
        color: white;
        font-size: 14px;
        padding: 10px 20px;
        width: 40%;
        max-width: 200px;
        border-radius: 7px;
        transition: all 0.3s ease-in-out;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        cursor: pointer;
    }

    .logout:hover {
        background-color: var(--yellow);
        color: var(--dark);
        box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
        transform: scale(1.05);
    }

    /* = CONTENT = */
    .big-content {
        margin: 4vh 0 4vh 20.5vw;
        width: 76.5vw;
        height: max-content;
    }

    .form-check-container {
        margin-bottom: 2vh;
        padding: 20px;
        background: #FFFFFF;
        border-radius: 10px;
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
    }

    .form-check-content {
        display: flex;
        gap: 30px;
        justify-content: space-between;
    }

    .form-check-laporan {
        flex: 1;
        padding: 20px;
        border: 1px solid #E0E0E0;
        border-radius: 8px;
        background: #F9F9F9;
    }

    .form-check-tanggapan {
        flex: 1;
        padding: 20px;
        border: 1px solid #E0E0E0;
        border-radius: 8px;
        background: #F9F9F9;
    }

    h2 {
        font-size: 22px;
        font-weight: bold;
        color: #4A4A4A;
        margin-bottom: 20px;
        text-align: center;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        margin-bottom: 15px;
    }

    .form-group-row {
        display: flex;
        gap: 20px;
    }

    label {
        font-weight: 500;
        margin-bottom: 5px;
        color: #4A4A4A;
    }

    input, textarea, select {
        padding: 10px;
        border: 1px solid #E0E0E0;
        border-radius: 5px;
        font-size: 14px;
        color: #4A4A4A;
        background: #FFFFFF;
        resize: none;
        outline: none;
        transition: border-color 0.3s ease;
    }

    input[disabled], textarea[disabled], select[disabled] {
        background: #F3F3F3;
        color: #B0B0B0;
        cursor: not-allowed;
    }

    .foto-preview {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 10px;
    }

    .foto-preview img {
        max-width: 100%;
        max-height: 200px;
        object-fit: cover;
    }

    .btn-download {
        text-decoration: none;
        color: #FFFFFF;
        background: #6A5ACD;
        padding: 8px 15px;
        border-radius: 5px;
        font-size: 14px;
        font-weight: bold;
        transition: background 0.3s ease;
    }

    .btn-download:hover {
        background: #5B4AC0;
    }

    .status-tanggapan {
        margin-top: 20px;
        padding: 15px;
        background: #F1F1F1;
        border-radius: 8px;
        text-align: center;
        font-size: 18px;
    }

    .status-status {
        font-weight: bold;
        color: #FF6F61;
    }

    @media (max-width: 768px) {
        .form-check-content {
            flex-direction: column;
        }
    }
</style>
<body>
    <!-- NAVBAR -->
    <nav>
        <div class="big-nav">
            <img class="icon" src="images/elapor-icon.png" alt="">
            <div class="content-nav">
                <section class="account">
                    <img src="images/user.png" alt="">
                    <section>
                        <h1><?= htmlspecialchars($level_user); ?></h1>
                        <a class="bio-class" href="bio.php"><p><?= htmlspecialchars($nama_user); ?></p></a>
                    </section>
                </section>
                <section style="margin-left: 2.5vw;" class="list-nav">
                    <li class="active-list-all"><a class="active" href="javascript:history.back()"><i class="material-icons-round">arrow_left</i> 
                        <div class="sect">
                            <h4>Back</h4>
                            <p style="font-size: 10px;">Halaman Sebelumnya</p>
                        </div>
                    </a></li>
                </section>
                <div class="button-logout">
                    <a class="logout" href="logout.php">Log Out</a>
                </div>
            </div>
        </div>
    </nav>
    <!-- CONTENT -->
    <div class="big-content">
        <div class="form-check-container">
            <div class="form-check-content">
                <!-- Preview: Form Laporan -->
                <div class="form-check-laporan">
                    <h2>Detail Laporan Anda</h2>
                    <form>
                        <div class="form-group-row">
                            <div class="form-group">
                                <label for="nama">Nama</label>
                                <input type="text" id="nama" name="nama" value="<?= htmlspecialchars($laporanDetail['nama_pelapor']); ?>" value disabled>
                            </div>
                            <div class="form-group">
                                <label for="nik">NIK</label>
                                <input type="text" id="nik" name="nik" value="<?= htmlspecialchars($laporanDetail['nik']); ?>" disabled>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="date">Tanggal Laporan</label>
                            <input style="width: max-content;" type="date" id="date" name="date" value="<?= htmlspecialchars($laporanDetail['tgl_pengaduan']); ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label for="laporan">Laporan</label>
                            <textarea id="laporan" name="laporan" rows="6" disabled><?= htmlspecialchars($laporanDetail['isi_laporan']); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="foto">Foto:</label>
                            <div class="foto-preview">
                                <?php if (!empty($laporanDetail['foto'])): ?>
                                    <img src="<?= htmlspecialchars($laporanDetail['foto']); ?>" alt="Foto Laporan" id="foto">
                                    <a href="<?= htmlspecialchars($laporanDetail['foto']); ?>" download class="btn-download">Download Foto</a>
                                <?php else: ?>
                                    <p>Pelapor tidak melampirkan foto.</p>
                                    <a href="#" class="btn-download" style="pointer-events: none; opacity: 0.5;">Download Foto</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- Preview: Form Tanggapan -->
                <div class="form-check-tanggapan">
                    <h2>Tanggapan Dari Admin</h2>
                    <form>
                        <div class="form-group-row">
                            <div class="form-group">
                                <label for="nama">Nama</label>
                                <input type="text" id="nama" name="nama" value="<?= htmlspecialchars($laporanDetail['nama_staff'] ?? 'Belum ditanggapi'); ?>" disabled>
                            </div>
                            <div class="form-group">
                                <label for="id_petugas">ID Petugas</label>
                                <input type="text" id="id_petugas" name="id_petugas" value="<?= htmlspecialchars($laporanDetail['no_petugas'] ?? 'Belum ditanggapi'); ?>" disabled>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="date">Tanggal Penanggapan</label>
                            <input style="width: max-content;" type="date" id="date" name="date" value="<?= htmlspecialchars($laporanDetail['tgl_tanggapan']); ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label for="tanggapan">Tanggapan</label>
                            <textarea id="tanggapan" name="tanggapan" rows="6" disabled><?= htmlspecialchars($laporanDetail['tanggapan'] ?? 'Belum ada tanggapan'); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="status">Status Laporan</label>
                            <select id="status" name="status" disabled>
                                <option value="belum diproses" <?= $laporanDetail['status'] == '0' ? 'selected' : ''; ?>>Belum Diproses</option>
                                <option value="proses" <?= $laporanDetail['status'] == 'proses' ? 'selected' : ''; ?>>Proses</option>
                                <option value="selesai" <?= $laporanDetail['status'] == 'selesai' ? 'selected' : ''; ?>>Selesai</option>
                            </select>
                        </div>
                    </form>
                </div>
            </div>
        
            <!-- Status Tanggapan -->
            <div class="status-tanggapan">
                <p><strong>Status:</strong> 
                <span class="status-status">
                    <?php
                    if ($laporanDetail['status'] == '0') {
                        echo 'Belum Ditanggapi';
                    } elseif ($laporanDetail['status'] == 'proses') {
                        echo 'Sedang Diproses';
                    } elseif ($laporanDetail['status'] == 'selesai') {
                        echo 'Selesai';
                    } else {
                        echo 'Tanpa Status';
                    }
                    ?>
                </span></p>
            </div>
        </div>        
    </div>
</body>
</html>
