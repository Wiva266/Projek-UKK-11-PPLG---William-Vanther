<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "pengaduan_masyarakat";

$connection = mysqli_connect($host, $username, $password, $database);

if (!$connection) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
} else {
    // echo "Koneksi berhasil!";
}
?>
