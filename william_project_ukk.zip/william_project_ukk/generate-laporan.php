<?php
session_start();
require 'connection.php';
require 'libraries/dompdf/autoload.inc.php';

use Dompdf\Dompdf;
use Dompdf\Options;

if (!isset($_SESSION['id_petugas'])) {
    header('Location: login.php');
    exit();
}

$query = "
    SELECT p.id_pengaduan, p.nik, p.tgl_pengaduan, p.isi_laporan, p.status, 
           t.tgl_tanggapan, t.id_petugas
    FROM pengaduan p
    LEFT JOIN tanggapan t ON p.id_pengaduan = t.id_pengaduan
";
$result = mysqli_query($connection, $query);
$dataLaporan = mysqli_fetch_all($result, MYSQLI_ASSOC);

function getStatusText($status) {
    return $status === '0' ? 'Belum Ditanggapi' : ($status === 'proses' ? 'Sedang Diproses' : 'Selesai');
}

// Config Dompdf
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true);
$dompdf = new Dompdf($options);

// HTML untuk PDF
$html = '
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Pengaduan</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
        th { background-color: #f2f2f2; font-weight: bold; }
    </style>
</head>
<body>
    <h2 style="text-align: center;">Laporan Pengaduan</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>NIK</th>
                <th>Isi Laporan</th>
                <th>Tanggal Pengaduan</th>
                <th>Status</th>
                <th>Tanggal Tanggapan</th>
                <th>ID Petugas</th>
            </tr>
        </thead>
        <tbody>';

foreach ($dataLaporan as $laporan) {
    $html .= '
            <tr>
                <td>' . htmlspecialchars($laporan['id_pengaduan']) . '</td>
                <td>' . htmlspecialchars($laporan['nik']) . '</td>
                <td>' . htmlspecialchars($laporan['isi_laporan']) . '</td>
                <td>' . htmlspecialchars($laporan['tgl_pengaduan']) . '</td>
                <td>' . getStatusText($laporan['status']) . '</td>
                <td>' . ($laporan['tgl_tanggapan'] ?? '-') . '</td>
                <td>' . ($laporan['id_petugas'] ?? '-') . '</td>
            </tr>';
}

$html .= '
        </tbody>
    </table>
</body>
</html>';

// Render PDF menggunakan Dompdf
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape');
$dompdf->render();

// Output PDF ke browser
$dompdf->stream("laporan_pengaduan.pdf", ["Attachment" => false]);
?>
