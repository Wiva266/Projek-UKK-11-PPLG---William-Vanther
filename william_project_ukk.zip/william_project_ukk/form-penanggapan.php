<?php
session_start();
include 'connection.php';

$id_pengaduan = isset($_GET['id']) ? filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT) : null;
$pengaduan = [];

if ($id_pengaduan) {
    $sql = "SELECT m.nama, p.nik, p.tgl_pengaduan, p.isi_laporan, p.foto
        FROM pengaduan p
        JOIN masyarakat m ON p.nik = m.nik
        WHERE p.id_pengaduan = ?";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param('i', $id_pengaduan);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $pengaduan = $result->fetch_assoc();
    } else {
        die("Data pengaduan tidak ditemukan.");
    }
    $stmt->close();
} else {
    die("ID pengaduan tidak valid.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_pengaduan = filter_var($_POST['id_pengaduan'], FILTER_SANITIZE_NUMBER_INT);
    $tanggapan = htmlspecialchars($_POST['tanggapan']);
    $status = htmlspecialchars($_POST['status']);
    $id_petugas = $_SESSION['id_petugas'];

    if (!empty($id_pengaduan) && !empty($tanggapan) && !empty($status)) {
        $sql = "INSERT INTO tanggapan (id_pengaduan, tgl_tanggapan, tanggapan, id_petugas) 
                VALUES (?, NOW(), ?, ?)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param('isi', $id_pengaduan, $tanggapan, $id_petugas);

        if ($stmt->execute()) {
            $update_sql = "UPDATE pengaduan SET status = ? WHERE id_pengaduan = ?";
            $update_stmt = $connection->prepare($update_sql);
            $update_stmt->bind_param('si', $status, $id_pengaduan);

            if ($update_stmt->execute()) {
                header('Location: list-laporan.php');
                exit();
            } else {
                echo "Gagal memperbarui status laporan.";
            }
        } else {
            echo "Gagal menyimpan tanggapan.";
        }
        $stmt->close();
    } else {
        echo "Semua field harus diisi.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="images/elapor-xicon.png">
    <title>FORM PENANGGAPAN E-LAPOR | DASHBOARD LAYANAN PELAPORAN MASYARAKAT</title>
</head>
<style>
    /* === E - LAPOR ROOT === */
    @import url('https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap');

    :root {
        --black: #34495E;
        --dark: #1D1A39;
        --purple-dark: #451952;
        --purple: #7324c7;
        --red-dark: #862549;
        --pink-lilac: #AE445A;
        --yellow: #F39F5A;
        --white-gray: #E8BCB9;
    }

    * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
        text-decoration: none;
        list-style: none;
        font-family: 'Nunito';
        color: var(--black);
    }

    body {
        background-color: #f1f2f7;
    }

    html {
        scroll-behavior: smooth;
    }

    ::-webkit-scrollbar {
        width: 12px;
    }

    ::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }

    ::-webkit-scrollbar-thumb {
        background: var(--purple);
        border-radius: 10px;
        border: 2px solid #f1f1f1;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: var(--purple-dark);
    }

    /* = NAVBAR = */
    nav {
        width: 18vw;
        height: 100vh;
        position: fixed;
        background-color: #f1f2f7;
        padding-bottom: 8vh;
    }

    .big-nav {
        border-right: 2px solid #d3d3d388;
        height: 100%;
    }

    .account {
        display: flex;
        align-items: center;
        flex-direction: column;
        justify-content: center;
        text-align: center;
        gap: 13px;
        margin: 4vh 0px 11vh 0px;
    }

    .bio-class:hover {
        text-decoration: underline;
    }

    .icon{
        width: 30%;
        margin-left: 2.5vw;
        padding-top: 1.7vh;
        color: var(--purple-dark);
        text-transform: uppercase;
    }
    .account img {
        width: 45%;
        border-radius: 50%;
        background-color: #C9B6F2;
        margin-top: 2vh;
    }
    .account section h1 {
        font-size: 20px;
        font-weight: bolder;
        margin: -1px 0;
    }
    .account section p {
        font-size: 11px;
        width: 220px;
        transition: all .3s ease-in-out;
    }
    .account section p:hover {
        color: #6c7b87;
    }

    .list-nav a {
        text-align: left;
        display: flex;
        align-items: center;
        gap: 20px;
        margin: 15px 0px;
    }

    .list-nav a i {
        background-color: white;
        color: gray;
        padding: 7px;
        border-radius: 12px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.01);
    }

    .list-nav a.active i {
        background-color: var(--purple);
        color: white;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .list-nav a.active h4, .list-nav a.active p {
        color: var(--purple);
    }

    .list-nav li {
        transform: scale(1);
        transition: all 0.3s ease-in-out;
    }
    .list-nav li:hover {
        transform: scale(1.01);
    }

    .button-logout {
        margin-top: 34.5vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .logout {
        display: flex;
        justify-content: center;
        align-items: center;
        font-weight: bold;
        background-color: var(--purple);
        color: white;
        font-size: 14px;
        padding: 10px 20px;
        width: 40%;
        max-width: 200px;
        border-radius: 7px;
        transition: all 0.3s ease-in-out;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        cursor: pointer;
    }

    .logout:hover {
        background-color: var(--yellow);
        color: var(--dark);
        box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
        transform: scale(1.05);
    }

    /* = CONTENT = */
    .big-content {
        margin: 4vh 0 4vh 20.5vw;
        width: 76.5vw;
    }

    /* Container Form Laporan dan Tanggapan */
    .form-container {
        display: flex;
        gap: 20px;
        justify-content: space-between;
        height: 100%;
        padding: 20px;
        background: #FFFFFF;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .form-laporan, .form-tanggapan {
        flex: 1;
        padding: 20px;
        border: 1px solid #E0E0E0;
        border-radius: 8px;
        background: #F9F9F9;
    }

    h2 {
        font-size: 20px;
        margin-bottom: 15px;
        color: #4A4A4A;
        text-align: center;
        font-weight: bold;
    }

    .form-group {
        display: flex;
        flex-direction: column;
        margin-bottom: 15px;
    }

    .form-group-row {
        display: flex;
        gap: 10px;
    }

    label {
        font-weight: 500;
        margin-bottom: 5px;
        color: #4A4A4A;
    }

    input, textarea, select {
        padding: 10px;
        border: 1px solid #E0E0E0;
        border-radius: 5px;
        font-size: 14px;
        color: #4A4A4A;
        background: #FFFFFF;
        resize: none;
        outline: none;
        transition: border-color 0.3s ease;
    }

    input[disabled], textarea[disabled] {
        background: #F3F3F3;
        color: #B0B0B0;
        cursor: not-allowed;
    }

    .foto-preview {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 10px;
    }

    .foto-preview img {
        max-width: 100%;
        max-height: 200px;
        object-fit: cover;
    }

    .btn-download {
        text-decoration: none;
        color: #FFFFFF;
        background: #6A5ACD;
        padding: 8px 15px;
        border-radius: 5px;
        font-size: 14px;
        font-weight: bold;
        transition: background 0.3s ease;
    }

    .btn-download:hover {
        background: #5B4AC0;
    }

    .btn-submit {
        padding: 10px 20px;
        border: none;
        border-radius: 5px;
        background: #6A5ACD;
        color: #FFFFFF;
        font-size: 16px;
        cursor: pointer;
        transition: background 0.3s ease;
    }

    .btn-submit:hover {
        background: #5B4AC0;
    }
</style>
<body>
    <!-- NAVBAR -->
    <nav>
        <div class="big-nav">
            <img class="icon" src="images/elapor-icon.png" alt="">
            <div class="content-nav">
                <section class="account">
                    <img src="images/user.png" alt="">
                        <section>
                            <h1>
                                <?php 
                                    if (isset($_SESSION['level']) && ($_SESSION['level'] == 'admin' || $_SESSION['level'] == 'petugas')) {
                                        echo ucfirst($_SESSION['level']);
                                    }
                                ?>
                            </h1>
                            <a class="bio-class" href="bio.php">
                                <p>
                                    <?php 
                                        if (isset($_SESSION['nama_petugas'])) {
                                            echo htmlspecialchars($_SESSION['nama_petugas']);
                                        }
                                    ?>
                                </p>
                            </a>
                        </section>
                </section>
                <section style="margin-left: 2.5vw;" class="list-nav">
                    <li class="active-list-all"><a class="active" href="javascript:history.back()"><i class="material-icons-round">arrow_left</i> 
                        <div class="sect">
                            <h4>Back</h4>
                            <p style="font-size: 10px;">Halaman Sebelumnya</p>
                        </div>
                    </a></li>
                </section>
                <div class="button-logout">
                    <a class="logout" href="logout.php">Log Out</a>
                </div>
            </div>
        </div>
    </nav>
    <!-- CONTENT -->
    <div class="big-content">
        <div class="form-container">
            <!-- Kolom Kiri: Form Laporan (Read-Only) -->
            <div class="form-laporan">
                <h2>Detail Laporan</h2>
                <form>
                    <div class="form-group-row">
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" id="nama" name="nama" value="<?= htmlspecialchars($pengaduan['nama'] ?? ''); ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label for="nik">NIK</label>
                            <input type="text" id="nik" name="nik" value="<?= htmlspecialchars($pengaduan['nik'] ?? ''); ?>" disabled>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="tgl_pengaduan">Tanggal Pengaduan</label>
                        <input id="tgl_pengaduan" type="date" name="tgl_pengaduan" value="<?= htmlspecialchars($pengaduan['tgl_pengaduan'] ?? ''); ?>" disabled>
                    </div>
                    <div class="form-group">
                        <label for="isi_laporan">Laporan</label>
                        <textarea id="isi_laporan" name="isi_laporan" rows="6" disabled><?= htmlspecialchars($pengaduan['isi_laporan'] ?? ''); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="foto">Foto:</label>
                            <div class="foto-preview">
                                <?php if (!empty($pengaduan['foto'])): ?>
                                    <img src="<?= htmlspecialchars($pengaduan['foto']); ?>" alt="Foto Laporan" id="foto">
                                    <a href="<?= htmlspecialchars($pengaduan['foto']); ?>" download class="btn-download">Download Foto</a>
                                <?php else: ?>
                                    <p>Pelapor tidak melampirkan foto.</p>
                                    <a href="#" class="btn-download" style="pointer-events: none; opacity: 0.5;">Download Foto</a>
                                <?php endif; ?>
                            </div>
                    </div>
                </form>
            </div>
        
            <!-- Kolom Kanan: Form Tanggapan -->
            <div class="form-tanggapan">
                <h2>Form Tanggapan</h2>
                <form action="" method="POST">
                    <input type="hidden" name="id_pengaduan" value="<?= htmlspecialchars($_GET['id']); ?>">
                    <div class="form-group">
                        <label for="tanggapan">Tanggapan</label>
                        <textarea id="tanggapan" name="tanggapan" rows="6" placeholder="Masukkan tanggapan Anda di sini..." required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="status">Status Laporan</label>
                        <select id="status" name="status" required disabled>
                            <option value="selesai" disabled selected>Status laporan akan dianggap selesai setelah ditanggapi.</option>
                            <input type="hidden" name="status" value="selesai">
                        </select>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn-submit">Kirim Tanggapan</button>
                    </div>
                </form>
            </div>
        </div>        
    </div>
</body>
</html>