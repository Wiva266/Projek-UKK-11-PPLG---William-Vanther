<?php
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nik = $_POST['nik'];
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $telp = $_POST['telp'];
    $password = $_POST['password'];

    if (strlen($nik) !== 16) {
        $error = "NIK must be exactly 16 characters!";
    } elseif (empty($nik) || empty($nama) || empty($username) || empty($telp) || empty($password)) {
        $error = "All fields are required!";
    } else {
        $query = "SELECT * FROM masyarakat WHERE nik = ?";
        $stmt = $connection->prepare($query);
        $stmt->bind_param('s', $nik);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "NIK already registered!";
        } else {
            $hashed_password = md5($password);

            $query = "INSERT INTO masyarakat (nik, nama, username, telp, password) VALUES (?, ?, ?, ?, ?)";
            $stmt = $connection->prepare($query);
            $stmt->bind_param('sssss', $nik, $nama, $username, $telp, $hashed_password);

            if ($stmt->execute()) {
                $success = "Registration successful! Please log in.";
            } else {
                $error = "Registration failed. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="icon" type="image/x-icon" href="images/elapor-xicon.png">
    <title>REGISTER E-LAPOR | DASHBOARD LAYANAN PELAPORAN MASYARAKAT</title>
</head>
<style>
    /* === E - LAPOR ROOT === */
    @import url('https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap');

    :root {
        --black: #34495E;
        --dark: #1D1A39;
        --purple-dark: #451952;
        --purple: #7324c7;
        --red-dark: #862549;
        --pink-lilac: #AE445A;
        --yellow: #F39F5A;
        --white-gray: #E8BCB9;
    }

    * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
        text-decoration: none;
        list-style: none;
        font-family: 'Nunito';
        color: var(--black);
    }

    body {
        position: relative;
        min-height: 100vh;
        margin: 0;
    }

    body::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: url(images/texture-formloginreg.png) center/cover no-repeat;
        opacity: 0.2;
        z-index: -1;
    }

    html {
        scroll-behavior: smooth;
    }

    ::-webkit-scrollbar {
        width: 12px;
    }

    ::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }

    ::-webkit-scrollbar-thumb {
        background: var(--purple);
        border-radius: 10px;
        border: 2px solid #f1f1f1;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: var(--purple-dark);
    }

    /* = TITLE COLOR = */
    .title-to-combine {
        display: flex;
        gap: 6.5px;
    }
    .coloring-sub {
        color: var(--purple);
    }

    /* = LOGIN FORM = */
    .big-login {
        width: 100vw;
        height: 100vh;

        display: flex;
        justify-content: center;
        align-items: center;
    }

    .login {
        width: 70%;
        height: 75%;
        display: flex;
        justify-content: center;
        align-items: center;
        border-radius: 25px;
        background-color: rgba(255, 255, 255, 0.909);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .img-side {
        width: 51.5%;
        padding: 5vw;
        border-radius: 25px;
        background-color: var(--purple);
    }

    .form-login {
        width: 50%;
        display: flex;
        justify-content: center;
        padding: 100px;
    }

    .form-login, .form-login section {
        display: flex;
        justify-content: center;
        flex-direction: column;
    }

    .input-container {
        display: flex;
        flex-direction: column;
        width: 100%;
        max-width: 400px;
    }

    .input-container input {
        width: 100%;
        margin: 5px 0;
        padding: 10px 15px;
        border: 1px solid #ddd;
        border-radius: 5px; 
        font-size: 14px;
        color: #333;
        outline: none;
        transition: border-color 0.3s ease, box-shadow 0.3s ease;
    }

    .input-container input::placeholder {
        color: #aaa;
        font-size: 14px;
    }

    .input-container input:focus {
        border-color: #7324c7;
        box-shadow: 0 0 5px rgba(115, 36, 199, 0.3);
    }

    .select-to-log-or-reg {
        display: flex;
        align-items: center;
        gap: 5px;
        font-size: 15px;
        padding: 5px 2px;
    }

    .select-to-log-or-reg a {
        color: var(--purple);
        text-decoration: none;
        position: relative;
        overflow: hidden;
    }

    .select-to-log-or-reg a::before {
        content: '';
        position: absolute;
        bottom: 0;
        left: -100%;
        width: 100%;
        height: 2px;
        background-color: var(--purple);
        transition: left 0.3s ease;
    }

    .select-to-log-or-reg a:hover::before {
        left: 0;
    }

    .submit-to-dashboard {
        background-color: var(--purple);
        display: flex;
        align-items: center;
        text-align: center;
        justify-content: center;
        padding: 10px 20px;
        border-radius: 7px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        text-decoration: none;
        transition: all 0.3s ease;

        width: 100%;
        border: none;
        color: white;
        font-size: 16px;
        font-weight: bold;
        text-transform: uppercase;
        cursor: pointer;
    }

    .submit-to-dashboard:hover {
        background-color: #7c39b3;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        transform: scale(1.01);
    }

    .submit-to-dashboard {
    }

    .toggle-password {
        cursor: pointer;
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
    }

    .toggle-password i {
        color: var(--purple);
    }

    .message {
        font-size: .9rem;
        font-weight: bold;
        margin-top: 15px;
        text-align: center;
        padding: 7px;
        border-radius: 5px;
    }
    .success {
        color: #ffffff;
        background-color: #6a0dad;
    }
    .error {
        color: #ffffff;
        background-color: #d32f2f;
    }
</style>
<body>
    <div class="big-login">
        <div class="login">
            <img class="img-side" src="images/login-register.png" alt="login-img">
            <section class="form-login">
                <img style="width: 20vw; margin-bottom: 3vh;" src="images/elapor-icon.png" alt="">
                <form action="" method="POST" class="input-container">
                    <?php if (!empty($error)): ?>
                        <p class="message error"><?= $error ?></p>
                    <?php elseif (!empty($success)): ?>
                        <p class="message success"><?= $success ?></p>
                    <?php endif; ?>
                    <input type="number" name="nik" id="nik" placeholder="Input NIK (16 digits)" required minlength="16" maxlength="16">
                    <input type="text" name="nama" id="nama" placeholder="Input Long Name" required>
                    <input type="text" name="username" id="username" placeholder="Input Username" required>
                    <input type="number" name="telp" id="telp" placeholder="Handphone Number" required>
                    <div style="position: relative;">
                        <input type="password" name="password" id="password" placeholder="Input Password" required>
                        <span class="toggle-password" onclick="togglePassword()">
                            <i class="fas fa-eye" id="eye-icon"></i>
                        </span>
                    </div>
                    <div class="select-to-log-or-reg">
                        <p>Have an account?</p>
                        <a href="login.php">Login</a>
                    </div>
                    <button class="submit-to-dashboard" type="submit">Sign Up</button>
                </form>
            </section>
        </div>
    </div>

    <script>
        function togglePassword() {
            const passwordField = document.getElementById("password");
            const eyeIcon = document.getElementById("eye-icon");

            if (passwordField.type === "password") {
                passwordField.type = "text";
                eyeIcon.classList.replace("fa-eye", "fa-eye-slash");
            } else {
                passwordField.type = "password";
                eyeIcon.classList.replace("fa-eye-slash", "fa-eye");
            }
        }
    </script>
</body>
</html>
