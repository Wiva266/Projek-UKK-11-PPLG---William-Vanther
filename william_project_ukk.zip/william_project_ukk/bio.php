<?php
session_start();

if (!isset($_SESSION['id_petugas']) && !isset($_SESSION['nik'])) {
    header("Location: login.php");
    exit();
}

include 'connection.php';

if (isset($_SESSION['id_petugas'])) {
    $id_petugas = $_SESSION['id_petugas'];

    $sql = "SELECT id_petugas, nama_petugas, username, telp, level FROM petugas WHERE id_petugas = ?";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("s", $id_petugas);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    $id = $row['id_petugas'];
    $nama = $row['nama_petugas'];
    $username = $row['username'];
    $telp = $row['telp'];
    $level = $row['level'];
} else {
    $nik = $_SESSION['nik'];

    $sql = "SELECT nik, nama, username, telp FROM masyarakat WHERE nik = ?";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("s", $nik);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    $id = $row['nik'];
    $nama = $row['nama'];
    $username = $row['username'];
    $telp = $row['telp']; 
    $level = 'masyarakat';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
    <link rel="icon" type="image/x-icon" href="images/elapor-xicon.png">
    <title>BIO - E-LAPOR | DASHBOARD LAYANAN PELAPORAN MASYARAKAT</title>
</head>
<style>
    /* === E - LAPOR ROOT === */
    @import url('https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap');

    :root {
        --black: #34495E;
        --dark: #1D1A39;
        --purple-dark: #451952;
        --purple: #7324c7;
        --red-dark: #862549;
        --pink-lilac: #AE445A;
        --yellow: #F39F5A;
        --white-gray: #E8BCB9;
    }

    * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
        text-decoration: none;
        list-style: none;
        font-family: 'Nunito';
        color: var(--black);
    }

    body {
        background-color: #f1f2f7;
    }

    html {
        scroll-behavior: smooth;
    }

    ::-webkit-scrollbar {
        width: 12px;
    }

    ::-webkit-scrollbar-track {
        background: #f1f1f1;
        border-radius: 10px;
    }

    ::-webkit-scrollbar-thumb {
        background: var(--purple);
        border-radius: 10px;
        border: 2px solid #f1f1f1;
    }

    ::-webkit-scrollbar-thumb:hover {
        background: var(--purple-dark);
    }

    /* = NAVBAR = */
    nav {
        width: 18vw;
        height: 100vh;
        position: fixed;
        background-color: #f1f2f7;
        padding-bottom: 8vh;
    }

    .big-nav {
        border-right: 2px solid #d3d3d388;
        height: 100%;
    }

    .account {
        display: flex;
        align-items: center;
        flex-direction: column;
        justify-content: center;
        text-align: center;
        gap: 13px;
        margin: 4vh 0 11vh 0;
    }

    .bio-class:hover {
        text-decoration: underline;
    }

    .icon {
        width: 30%;
        margin-left: 2.5vw;
        padding-top: 1.7vh;
        color: var(--purple-dark);
        text-transform: uppercase;
    }

    .account img {
        width: 45%;
        border-radius: 50%;
        background-color: #C9B6F2;
        margin-top: 2vh;
    }

    .account section h1 {
        font-size: 20px;
        font-weight: bolder;
        margin: -1px 0;
        margin-bottom: -6px;
    }

    .account section a {
        font-size: 11px;
        width: 220px;
        transition: all .3s ease-in-out;
    }

    .account section p:hover {
        color: #6c7b87;
    }

    .list-nav a {
        text-align: left;
        display: flex;
        align-items: center;
        gap: 20px;
        margin: 17px 10px;
    }

    .list-nav a i {
        background-color: white;
        color: gray;
        padding: 7px;
        border-radius: 12px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.01);
    }

    .list-nav a.active i {
        background-color: var(--purple);
        color: white;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .list-nav a.active h4, .list-nav a.active p {
        color: var(--purple);
    }

    .list-nav li {
        transform: scale(1);
        transition: all 0.3s ease-in-out;
    }

    .list-nav li:hover {
        transform: scale(1.01);
    }

    .button-logout {
        margin-top: 34.5vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .logout {
        display: flex;
        justify-content: center;
        align-items: center;
        font-weight: bold;
        background-color: var(--purple);
        color: white;
        font-size: 14px;
        padding: 10px 20px;
        width: 40%;
        max-width: 200px;
        border-radius: 7px;
        transition: all 0.3s ease-in-out;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        cursor: pointer;
    }

    .logout:hover {
        background-color: var(--yellow);
        color: var(--dark);
        box-shadow: 0 6px 8px rgba(0, 0, 0, 0.15);
        transform: scale(1.05);
    }

    /* = CONTENT = */
    .big-content {
        margin: 4vh 0 4vh 20.5vw;
        width: 76.5vw;
        height: 92vh;
    }

    .bio-container {
        background-color: #ffffff;
        border-radius: 15px;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        padding: 3vw;
        width: 100%;
        max-width: 600px;
        margin: auto;
        text-align: center;
        position: relative;
        overflow: hidden;
    }

    .bio-container h1 {
        font-size: 32px;
        margin-bottom: 20px;
        color: var(--purple);
        font-weight: bold;
    }

    .bio-container .bio-item {
        margin: 15px 0;
        font-size: 18px;
        font-weight: 500;
        color: var(--dark);
        text-align: left;
    }

    .bio-container .bio-label {
        font-weight: bold;
        color: var(--purple-dark);
    }

    .bio-container input {
        width: 100%;
        padding: 12px;
        margin-top: 8px;
        border-radius: 8px;
        border: 1px solid #ccc;
        font-size: 16px;
        color: var(--dark);
        background-color: #f9f9f9;
        text-align: left;
    }

    .bio-container input:focus {
        outline: none;
        border-color: var(--purple);
    }
</style>
<body>
    <!-- NAVBAR -->
    <nav>
        <div class="big-nav">
            <img class="icon" src="images/elapor-icon.png" alt="">
            <div class="content-nav">
                <section class="account">
                    <img src="images/user.png" alt="User Icon">
                    <section>
                        <h1><?php echo ucfirst($level); ?></h1>
                        <a href="bio.php" class="bio-class"><?php echo htmlspecialchars($nama); ?></a>
                    </section>
                </section>
                <section style="margin-left: 2.5vw;" class="list-nav">
                    <li class="active-list-all">
                        <a class="active" href="javascript:history.back()">
                            <i class="material-icons-round">arrow_left</i> 
                            <div class="sect">
                                <h4>Back</h4>
                                <p style="font-size: 10px;">Halaman Sebelumnya</p>
                            </div>
                        </a>
                    </li>
                </section>
                <div class="button-logout">
                    <a class="logout" href="logout.php">Log Out</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- CONTENT -->
    <div class="big-content">
        <div class="bio-container">
            <h1>Bio User</h1>
            <div class="bio-item">
                <span class="bio-label">Username:</span>
                <input type="text" value="<?php echo htmlspecialchars($username); ?>" readonly>
            </div>
            <div class="bio-item">
                <span class="bio-label">Nama:</span>
                <input type="text" value="<?php echo htmlspecialchars($nama); ?>" readonly>
            </div>
            <div class="bio-item">
                <span class="bio-label"><?php echo ($level == 'masyarakat') ? 'NIK:' : 'ID Petugas:'; ?></span>
                <input type="text" value="<?php echo htmlspecialchars($id); ?>" readonly>
            </div>
            <div class="bio-item">
                <span class="bio-label">Telepon:</span>
                <input type="text" value="<?php echo htmlspecialchars($telp); ?>" readonly>
            </div>
            <div class="bio-item">
                <span class="bio-label">Level:</span>
                <input type="text" value="<?php echo ucfirst($level); ?>" readonly>
            </div>
        </div>
    </div>
</body>
</html>
